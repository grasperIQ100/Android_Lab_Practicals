package com.example.lab_06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.BaseAdapter;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

// step-1 local reference
    AutoCompleteTextView autoComplete;
    String[] countries = new String[]{"India","Japan","Mexico", "France","Nepal","Canada","America","Russia","UK","England"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // step-2 binding view
        autoComplete = findViewById(R.id.autoComplete);

        //types-:
        // ArrayAdapter - one dimensional arrays,listview, single Source/UI,Single type.EG-()
        // BaseAdapter - Multiple source/UI, EG- Whatsapp(chats,date,vidoe,images)

    //Step-3 Implement adapter

        ArrayAdapter<String> adt = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                countries);

        autoComplete.setAdapter(adt);

    }


}