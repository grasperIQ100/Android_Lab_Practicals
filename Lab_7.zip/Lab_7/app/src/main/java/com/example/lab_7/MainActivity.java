package com.example.lab_7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Step 1 - local reference
    Button btnnext, openbrow,opencalc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //step 2 - binding views
        btnnext = findViewById(R.id.btnnext);
        openbrow = findViewById(R.id.openbrowser);
        opencalc = findViewById(R.id.openlab);


        //step 3 - implement listener
        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(MainActivity.this,
                        NextActivity.class);
                startActivity(i1);

            }
        });
        openbrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.co.in"));
                startActivity(i1);

            }
        });
        opencalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent("myHandler");
                startActivity(i1);


            }
        });
    }
}