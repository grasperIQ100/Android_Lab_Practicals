package com.example.lab12_contextmenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
        // step 1 - local reference
    ListView lvList;
    ArrayList<String> myList = new ArrayList<>();
    ArrayAdapter<String> adt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // step 2 - binding

        myList.add("Maharana Pratap");
        myList.add("Chhatrapati Shivaji");
        myList.add("Bhagat Singh");
        myList.add("Chandrashekhar Azad");
        myList.add("Sardar Patel");
        myList.add("Rani Laxmi Bai");
        myList.add("Samrat Ashok");
        myList.add("Prithviraj Chauhan");
        myList.add("Bala Saheb Thakrey");
        myList.add("Subhash Chandra Bose");
        myList.add("Atal Bihari Vajpayee");
        myList.add("Dr.Apj Abdul Kalam");
        lvList = findViewById(R.id.lvList);
    //data view
        adt = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                myList
        );
        lvList.setAdapter(adt);
        registerForContextMenu(lvList);

    }
    // implementation
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_context_menu,menu);

    }


    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();

        switch (item.getItemId()){
            case R.id.menuDelete:
                myList.remove(info.position);
                adt.notifyDataSetChanged();
                return true;
            case R.id.menuUpdate:
                myList.add("");
                adt.notifyDataSetChanged();
                return true;
            default:
                return super.onContextItemSelected(item);

        }

    }
}