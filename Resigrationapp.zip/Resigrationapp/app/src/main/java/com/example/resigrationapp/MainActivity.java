package com.example.resigrationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnlog,btnsign;
    EditText edittextName,edittextpassword;
    String Uusername="admin";
    String upassword="admin@12";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittextpassword=findViewById(R.id.upass);
        edittextName=findViewById(R.id.uname);
        btnlog=findViewById(R.id.btnlog);
        btnsign=findViewById(R.id.btnsign);

        btnlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username=edittextName.getText().toString();
                String password=edittextpassword.getText().toString();

                if(username.equals("")||password.equals("")){
                    Toast.makeText(MainActivity.this, "please enter the value", Toast.LENGTH_SHORT).show();
                }
                else {
                     if (username.equals(Uusername)&&password.equals(upassword)){
                         Intent intent2 = new Intent(MainActivity.this,loginsucces2.class);
                         startActivity(intent2);
                }
                     else{
                         Toast.makeText(MainActivity.this, "Please enter value Credentials", Toast.LENGTH_SHORT).show();
                     }
                }
                //Intent intent = new Intent(MainActivity.this,signup2.class);
                //startActivity(intent);
            }
            });
        btnsign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent( MainActivity.this,signup2.class);
                startActivity(intent);
            }
        });
    }
}
