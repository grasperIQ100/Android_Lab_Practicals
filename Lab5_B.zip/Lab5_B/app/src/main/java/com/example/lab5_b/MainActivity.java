package com.example.lab5_b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Step-1 - Create local variable /instantiation

    EditText edtN1, edtN2;
    Button add,sub,div,mul,mod,sqr,AoSqr,AoCir,AoRec,AoTri,clear;
    TextView result;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    //step-2 - Binding view
        edtN1 = findViewById(R.id.edtNum1);
        edtN2 = findViewById(R.id.edtNum2);
        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        div = findViewById(R.id.division);
        mul = findViewById(R.id.multiply);
        mod = findViewById(R.id.Mod);
        sqr = findViewById(R.id.root);
        //Area of Square,circle,rectangle,triangle.
        AoSqr = findViewById(R.id.AreaOfSquare);
        AoCir = findViewById(R.id.AreaOfCircle);
        AoRec = findViewById(R.id.AreaOfRectangle);
        AoTri = findViewById(R.id.AreaOfTriangle);
        clear = findViewById(R.id.saaf);


        result = findViewById(R.id.output);


        // step-3 - implement listener
        if(edtN1.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter some Value the first Field",
                    Toast.LENGTH_SHORT).show();
        } else {
        }
        if(edtN2.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter some Value in the Second Field", Toast.LENGTH_SHORT).show();
        } else {
            
        }
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this,"Please enter some Value the first Field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some Value in the Second Field",
                            Toast.LENGTH_SHORT).show();
                }
                else {

                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN2.getText().toString());
                    int res = n1 + n2;

                    result.setText(String.valueOf(res));
                }

            }
        });


        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(edtN1.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this,"Please enter some Value the first Field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some Value in the Second Field",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN2.getText().toString());
                    int res = n1 - n2;
                    result.setText(String.valueOf(res));
                }
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this,"Please enter some Value the first Field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter some Value in the Second Field",
                            Toast.LENGTH_SHORT).show();
                }
                else{

                        int n1 = Integer.parseInt(edtN1.getText().toString());
                        int n2 = Integer.parseInt(edtN2.getText().toString());
                        int res = n1 / n2;
                        result.setText(String.valueOf(res));

                }
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in First Field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in second field",
                            Toast.LENGTH_SHORT).show();
                }
                else {


                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN2.getText().toString());
                    int res = n1 * n2;
                    result.setText(String.valueOf(res));
                }
            }
        });
        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in First field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in Second field",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN2.getText().toString());
                    int res = n1 % n2;
                    result.setText(String.valueOf(res));
                }
            }
        });
        sqr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some Value in first field",
                            Toast.LENGTH_SHORT).show();
                }
                int n1 = Integer.parseInt(edtN1.getText().toString());

                int res = n1*n1;
                result.setText(String.valueOf(res));

            }
        });
        AoSqr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in First field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in Second field",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN2.getText().toString());

                    int res = n1 * n2;
                    result.setText(String.valueOf(res));
                }
            }
        });
        AoCir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in First field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in Second field",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN1.getText().toString());

                    double res = 3.14 * (n1 * n2);

                    result.setText(String.valueOf(res));
                }


            }
        });
        AoRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in First field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in Second field",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    int n1 = Integer.parseInt(edtN1.getText().toString());
                    int n2 = Integer.parseInt(edtN2.getText().toString());

                    int res = n1 * n2;

                    result.setText(String.valueOf(res));
                }
            }
        });
        AoTri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtN1.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in First field",
                            Toast.LENGTH_SHORT).show();
                }
                else if(edtN2.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter some value in Second field",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    float n1 = Integer.parseInt(edtN1.getText().toString());
                    float n2 = Integer.parseInt(edtN2.getText().toString());

                    float res = (n1 * n2) / 2;
                    result.setText(String.valueOf(res));
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtN1.setText(null);
                edtN2.setText(null);
            }
        });





    }
}